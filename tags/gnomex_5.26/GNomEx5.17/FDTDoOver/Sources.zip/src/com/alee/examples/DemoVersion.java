/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples;

import com.alee.utils.XmlUtils;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.io.Serializable;
import java.net.URL;

/**
 * User: mgarin Date: 15.03.12 Time: 14:57
 */

@XStreamAlias ("DemoVersion")
public class DemoVersion implements Comparable<DemoVersion>, Serializable
{
    private String name;
    private int major;
    private int minor;

    public DemoVersion ( String name, int major, int minor )
    {
        super ();
        setName ( name );
        setMajor ( major );
        setMinor ( minor );
    }

    public String getName ()
    {
        return name;
    }

    public void setName ( String name )
    {
        this.name = name;
    }

    public int getMajor ()
    {
        return major;
    }

    public void setMajor ( int major )
    {
        this.major = major;
    }

    public int getMinor ()
    {
        return minor;
    }

    public void setMinor ( int minor )
    {
        this.minor = minor;
    }

    public int compareTo ( DemoVersion version )
    {
        if ( major < version.getMajor () )
        {
            return -1;
        }
        else if ( major > version.getMajor () )
        {
            return 1;
        }
        else
        {
            if ( minor < version.getMinor () )
            {
                return -1;
            }
            if ( minor > version.getMinor () )
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }

    public boolean equals ( Object object )
    {
        return object != null && object instanceof DemoVersion && compareTo ( ( DemoVersion ) object ) == 0;
    }

    public String getVersionString ()
    {
        return "v." + major + "." + minor;
    }

    public String toString ()
    {
        return getName () + " " + getVersionString ();
    }

    private static DemoVersion currentVersion = null;
    private static DemoVersion lastVersion = null;

    public static DemoVersion getCurrentVersion ()
    {
        if ( currentVersion == null )
        {
            currentVersion = ( DemoVersion ) XmlUtils.fromXML ( DemoVersion.class.getResourceAsStream ( "resources/version.xml" ) );
        }
        return currentVersion;
    }

    public static DemoVersion getLastVersion ()
    {
        if ( lastVersion == null )
        {
            try
            {
                lastVersion = ( DemoVersion ) XmlUtils.fromXML ( new URL ( WebLookAndFeelDemo.WEBLAF_SITE + "downloads/version.xml" ) );
            }
            catch ( Throwable e )
            {
                //
            }
        }
        return lastVersion;
    }
}